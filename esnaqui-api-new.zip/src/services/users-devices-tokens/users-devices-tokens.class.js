const { Service } = require('feathers-sequelize');

exports.UsersDevicesTokens = class UsersDevicesTokens extends Service {
  
};
